var windowWidth = jQuery(window).width();

if(windowWidth < 768){
	jQuery('.col1').find('.admin-navigtion').addClass('navigation-small');
}else{
	jQuery('.col1').find('.admin-navigtion').removeClass('navigation-small');
}

jQuery('.nav-button').on('click', function(e){
	e.preventDefault();
	var windowWidth = jQuery(window).width();
	if(windowWidth < 768){
		jQuery('.nav-button').closest('.admin-navigtion').addClass('navigation-small');
	}	
});

jQuery(window).resize(function(){
	var windowWidth = jQuery(window).width();

	if(windowWidth < 768){
		jQuery('.col1').find('.admin-navigtion').addClass('navigation-small');
		jQuery('.nav-button').on('click', function(e){
			e.preventDefault();
			jQuery(this).parents('.admin-navigtion').addClass('navigation-small');
		});
	}else{
		jQuery('.col1').find('.admin-navigtion').removeClass('navigation-small');
	}
});

jQuery(document).ready(function($) {
	
	$("#cs_vehicles_data").removeClass('ui-sortable-handle');
	// Booking Calculations	
	$('[id^=cs_extra_feat_], [name=cs_payment_part], [name=cs_payment_gateway]').click(function() {
        cs_booking_pricing();
    });
	
	// Booking Form Validation
	$('.cs-check-tabs').on('click', function(e) {
		var cs_detail_tab = $('#cs-detail-tab');
		var cs_booking_form = $('#cs-booking-form');
		var cs_form_validity = 'invalid';
		$(":input[required]").each(function () {                     
			if (cs_booking_form[0].checkValidity()){                
				cs_form_validity = 'valid';
			}
		});
		
		if(cs_form_validity == 'invalid') {
			$('.cs-reservation-tabs .booking-tabs').find('li').removeClass('active');
			cs_detail_tab.parents('li').addClass('active');
			
			var active = jQuery('.cs-reservation-tabs').find('.booking-tabs .active a').attr('href');

			$('.cs-ajax-listing .tab-content').find('.tabs').hide();
			$('.cs-ajax-listing .tab-content').find(active).show();
		
			alert('Please fill your details first.');
			return false;
		}
	});
	
	// Checkbox
	$('label.cs-chekbox').on('click', function() {
		var checkbox = $(this).children('input[type=checkbox]');
		
		if(checkbox.is(":checked")) {
			$('#'+checkbox.attr('name')).val(checkbox.val())
		}
		else{
			$('#'+checkbox.attr('name')).val('')
		}
	});
	
});

/**
* Toggle Function
*/
function cs_toggle(id) {
	jQuery("#" + id).slideToggle("slow");
}

/**
* Update Title
*/
function update_title(id) {
	var val;
	val = jQuery('#address_name' + id).val();
	jQuery('#address_name' + id).html(val);
}

/**
* Delete Confirm Html popup
*/
var html_popup = "<div id='confirmOverlay' style='display:block'> \
								<div id='confirmBox'><div id='confirmText'>Are you sure to do this?</div> \
								<div id='confirmButtons'><div class='button confirm-yes'>Delete</div>\
								<div class='button confirm-no'>Cancel</div><br class='clear'></div></div></div>"
								

/**
* Delete Item
*/
jQuery(".btndeleteit").live("click", function() {
	
	jQuery(this).parents(".parentdelete").addClass("warning");
	jQuery(this).parent().append(html_popup);

	jQuery(".confirm-yes").click(function() {
		jQuery(this).parents(".parentdelete").fadeOut(400, function() {
			jQuery(this).remove();
		});
		
		jQuery(this).parents(".parentdelete").each(function(){
			var lengthitem = jQuery(this).parents(".dragarea").find(".parentdelete").size() - 1;
			jQuery(this).parents(".dragarea").find("input.textfld") .val(lengthitem);
		});

		jQuery("#confirmOverlay").remove();
	
	});
	
	jQuery(".confirm-no").click(function() {
		jQuery(this).parents(".parentdelete").removeClass("warning");
		jQuery("#confirmOverlay").remove();
	});
	
	return false;
});

/**
* Create Popup
*/
function cs_createpop(data, type) {
	var _structure = "<div id='cs-pbwp-outerlay'><div id='cs-widgets-list'></div></div>",
		$elem = jQuery('#cs-widgets-list');
	jQuery('body').addClass("cs-overflow");
	if (type == "csmedia") {
		$elem.append(data);
	}
	if (type == "filter") {
		jQuery('#' + data).wrap(_structure).delay(100).fadeIn(150);
		jQuery('#' + data).parent().addClass("wide-width");
	}
	if (type == "filterdrag") {
		jQuery('#' + data).wrap(_structure).delay(100).fadeIn(150);
	}

}

/**
* Remove Popup
*/
function cs_remove_overlay(id, text) {
	jQuery("#cs-widgets-list .loader").remove();
	var _elem1 = "<div id='cs-pbwp-outerlay'></div>",
		_elem2 = "<div id='cs-widgets-list'></div>";
	$elem = jQuery("#" + id);
	jQuery("#cs-widgets-list").unwrap(_elem1);
	if (text == "append" || text == "filterdrag") {
		$elem.hide().unwrap(_elem2);
	}
	if (text == "widgetitem") {
		$elem.hide().unwrap(_elem2);
		jQuery("body").append("<div id='cs-pbwp-outerlay'><div id='cs-widgets-list'></div></div>");
		return false;

	}
	if (text == "ajax-drag") {
		jQuery("#cs-widgets-list").remove();
	}
	jQuery("body").removeClass("cs-overflow");
}

/**
 * Media upload
 */
jQuery(document).ready(function() {
	var ww = jQuery('#post_id_reference').text();
	window.original_send_to_editor = window.send_to_editor;
	window.send_to_editor_clone = function(html){
		imgurl = jQuery('a','<p>'+html+'</p>').attr('href');
		jQuery('#'+formfield).val(imgurl);
		tb_remove();
	}
	jQuery('input.uploadfile').click(function() {
		window.send_to_editor=window.send_to_editor_clone;
		formfield = jQuery(this).attr('name');
		tb_show('', 'media-upload.php?post_id=' + ww + '&type=image&TB_iframe=true');
		return false;
	});
});

/**
* Number Format
*/

function cs_number_format(num){
	return parseFloat(Math.round(num * 100) / 100).toFixed(2);
}

/**
* Change Package
*/
function cs_booking_pricing(){
	"use strict";
	
	// Booking Calculations
	var $ = jQuery;
	var cs_currency = '$';
	var cs_bkng_gross = 0;
	var cs_total_amount = 0;
	var cs_booking_fee = 0;
	var cs_booking_vat = 0;
	
	$("[id^=cs_extra_feat_]:checked").each(function() {
        var checked_features = jQuery(this).attr('data-price');
		cs_bkng_gross += parseFloat(checked_features);
    });
	
	cs_bkng_gross += parseFloat($('.cs-booking-gross').attr('data-gross'));
	
	$('.cs-booking-gross').html(cs_currency+cs_number_format(cs_bkng_gross));
		
	// Partial Amount Calculations
	var cs_partial_amount = 0;
	var cs_bkng_partial = $('#cs-partial-area strong').attr('data-partial');
	
	if(typeof(cs_bkng_partial) !== 'undefined'){
		
		if(cs_bkng_partial < 0){
			cs_bkng_partial = 1;
		}
		cs_partial_amount = (parseFloat(cs_bkng_gross)*parseInt(cs_bkng_partial))/100;
		
		$('#cs-partial-area strong').html(cs_currency+cs_number_format(cs_partial_amount));
	}
	
	// Default Gross Total in case of full Payment ON
	$('.cs-booking-total').html(cs_currency+cs_number_format(cs_bkng_gross));
	$('.cs-booking-total').attr('data-total', cs_number_format(cs_bkng_gross));
	
	// Partial Amount Calculations
	var cs_bkng_pay = $('[name=cs_payment_part]:checked').attr('id');
	
	if(typeof(cs_bkng_pay) !== 'undefined'){
		
		if(cs_bkng_pay == 'booking_part_pay'){
			$('.cs-booking-total').html(cs_currency+cs_number_format(cs_partial_amount));
			$('.cs-booking-total').attr('data-total', cs_number_format(cs_partial_amount));
			$('#cs-partial-area').show("slow");
		}
		else if(cs_bkng_pay == 'booking_full_pay'){
			$('.cs-booking-total').html(cs_currency+cs_number_format(cs_bkng_gross));
			$('.cs-booking-total').attr('data-total', cs_number_format(cs_bkng_gross));
			$('#cs-partial-area').hide("slow");
		}
	}
	
	cs_total_amount = $('.cs-booking-total').attr('data-total');
	
	// Fee Percentage
	var cs_fee_percent = $('[name=cs_payment_gateway]:checked').attr('data-fee');
	if(typeof(cs_fee_percent) !== 'undefined'){
		
		if(cs_fee_percent < 0){
			cs_fee_percent = 1;
		}
		
		cs_booking_fee = (cs_total_amount*cs_fee_percent)/100;
		$('.cs-booking-fee').attr('data-fee', cs_number_format(cs_booking_fee));
		$('.cs-booking-fee').html(cs_currency+cs_number_format(cs_booking_fee));
	}
		
	cs_booking_fee = $('.cs-booking-fee').attr('data-fee');

	if(typeof(cs_booking_fee) !== 'undefined' && cs_booking_fee > 0){
		cs_total_amount = parseFloat(cs_total_amount)+parseFloat(cs_booking_fee);
	}
	
	// VAT Percentage
	var cs_vat_percent = $('.cs-booking-vat').attr('data-percent');
	if(typeof(cs_vat_percent) !== 'undefined'){
		
		if(cs_vat_percent < 0){
			cs_vat_percent = 1;
		}
		
		cs_booking_vat = (cs_total_amount*cs_vat_percent)/100;
		$('.cs-booking-vat').attr('data-vat', cs_number_format(cs_booking_vat));
		$('.cs-booking-vat').html(cs_currency+cs_number_format(cs_booking_vat));
	}
		
	cs_booking_vat = $('.cs-booking-vat').attr('data-vat');

	if(typeof(cs_booking_vat) !== 'undefined' && cs_booking_vat > 0){
		cs_total_amount = parseFloat(cs_total_amount)+parseFloat(cs_booking_vat);
	}
	
	$('.cs-booking-grand').html(cs_currency+cs_number_format(cs_total_amount));
}

var counter_extra_feature = 0;
function add_extra_feature_to_list(admin_url, plugin_url) {
	counter_extra_feature++;
	var dataString = 'counter_extra_feature=' + counter_extra_feature +
		'&cs_extra_feature_title=' + jQuery("#cs_extra_feature_title").val() +
		'&cs_extra_feature_price=' + jQuery("#cs_extra_feature_price").val() +
		'&cs_extra_feature_type=' + jQuery("#cs_extra_feature_type").val() +
		'&cs_extra_feature_desc=' + jQuery("#cs_extra_feature_desc").val() +
		'&action=cs_add_extra_feature_to_list';
	jQuery(".feature-loader").html("<img src='" + plugin_url + "/assets/images/ajax-loader.gif' />");
	jQuery.ajax({
		type: "POST",
		url: admin_url,
		data: dataString,
		success: function(response) {
			jQuery("#total_extra_features").append(response);
			jQuery(".feature-loader").html("");
			cs_remove_overlay('add_extra_feature_title', 'append');
			jQuery("#cs_extra_feature_title").val("Title");
			jQuery("#cs_extra_feature_price").val("");
			jQuery("#cs_extra_feature_type").val("");
			jQuery("#cs_extra_feature_desc").val("");
		}
	});
	return false;
}

// Features
var counter_feats = 0;
function add_feats_to_list(admin_url, plugin_url) {
	counter_feats++;
	var dataString = 'counter_feats=' + counter_feats +
		'&cs_feats_title=' + jQuery("#cs_feats_title").val() +
		'&cs_feats_image=' + jQuery("#cs_feats_image").val() +
		'&cs_feats_desc=' + jQuery("#cs_feats_desc").val() +
		'&action=cs_add_feats_to_list';
	jQuery(".feature-loader").html("<img src='" + plugin_url + "/assets/images/ajax-loader.gif' />");
	jQuery.ajax({
		type: "POST",
		url: admin_url,
		data: dataString,
		success: function(response) {
			jQuery("#total_feats").append(response);
			jQuery(".feature-loader").html("");
			cs_remove_overlay('add_feats_title', 'append');
			jQuery("#cs_feats_title").val("Title");
			jQuery("#cs_feats_image").val("");
			jQuery("#cs_feats_desc").val("");
		}
	});
	return false;
}

// Properties
var counter_properties = 0;
function add_properties_to_list(admin_url, plugin_url) {
	counter_properties++;
	var dataString = 'counter_properties=' + counter_properties +
		'&cs_properties_title=' + jQuery("#cs_properties_title").val() +
		'&cs_properties_desc=' + jQuery("#cs_properties_desc").val() +
		'&action=cs_add_properties_to_list';
	jQuery(".property-loader").html("<img src='" + plugin_url + "/assets/images/ajax-loader.gif' />");
	jQuery.ajax({
		type: "POST",
		url: admin_url,
		data: dataString,
		success: function(response) {
			jQuery("#total_properties").append(response);
			jQuery(".property-loader").html("");
			cs_remove_overlay('add_properties_title', 'append');
			jQuery("#cs_properties_title").val("Title");
			jQuery("#cs_properties_desc").val("");
		}
	});
	return false;
}

//Reviews
var counter_dyn_reviews = 0;
function add_dyn_reviews_to_list(admin_url, plugin_url) {
	counter_dyn_reviews++;
	var dataString = 'counter_dyn_reviews=' + counter_dyn_reviews +
		'&cs_dyn_reviews_title=' + jQuery("#cs_dyn_reviews_title").val() +
		'&action=cs_add_dyn_reviews_to_list';
	jQuery(".feature-loader").html("<img src='" + plugin_url + "/assets/images/ajax-loader.gif' />");
	jQuery.ajax({
		type: "POST",
		url: admin_url,
		data: dataString,
		success: function(response) {
			jQuery("#total_dyn_reviews").append(response);
			jQuery(".feature-loader").html("");
			cs_remove_overlay('add_dyn_reviews_title', 'append');
			jQuery("#cs_dyn_reviews_title").val("Title");
		}
	});
	return false;
}



/**
 * @Gallery
 *
 */
jQuery( function($){
	// Product gallery file uploads
	var gallery_frame;

	jQuery('.add_gallery_data').on( 'click', 'a', function( event ) {
		var $el = $(this);
		
		var get_id 		   	   = $el.parents('.add_gallery_data').data('id');
		var rand_id 		   = $el.parents('.add_gallery_data').data('rand_id');
		
		var cs_plugin_url 	   = $("#cs_plugin_url").val();
		var $gallery_images    = $('#gallery_container ul.gallery_images');
		var attachment_ids 	   = $('#'+get_id).val();

		event.preventDefault();

		// If the media frame already exists, reopen it.
		if ( gallery_frame ) {
			gallery_frame.open();
			return;
		}

		// Create the media frame.
		gallery_frame = wp.media.frames.vehicle_gallery = wp.media({
			// Set the title of the modal.
			title: $el.data('choose'),
			button: {
				text: $el.data('update'),
			},
			states : [
				new wp.media.controller.Library({
					title: $el.data('choose'),
					filterable : 'all',
					multiple: true,
				})
			]
		});

		// When an image is selected, run a callback.
		gallery_frame.on( 'select', function() {

			var selection = gallery_frame.state().get('selection');

			selection.map( function( attachment ) {

				attachment = attachment.toJSON();
				
				if( attachment.type == 'image' ) {
					var gallery_url	= '<img src="' + attachment.url + '" />';
				} else if( attachment.type == 'audio' ) {
					var gallery_url	= '<i class="icon-documents"></i>';
				} else if( attachment.type == 'video' ) {
					var gallery_url	= '<i class="icon-video-camera"></i>';
				} else{
					var gallery_url	= '<i class="icon-documents"></i>';
				}
				
				if ( attachment.id ) {
					attachment_ids = attachment_ids ? attachment_ids + "," + attachment.id : attachment.id;

					$gallery_images.append('\
						<li class="image" data-attachment_id="' + attachment.id + '">\
							'+gallery_url+'\
							<div class="actions">\
								<span><a href="javascript:;" class="delete" title="' + $el.data('delete') + '"><i class="icon-times"></i></a></span>\
							</div>\
						</li>');
					}

				});

				var gallery = []; // more efficient than new Array()
				jQuery('#gallery_sortable_'+rand_id+' li').each(function(){
					var data_value	= jQuery.trim( jQuery(this).data('attachment_id'));
					 gallery.push(jQuery(this).data('attachment_id'));
				});
				
				jQuery("#"+get_id).val(gallery.toString());
			});

			// Finally, open the modal.
			gallery_frame.open();
		});
		
});

/**
 * @Sorting
 *
 */
 
function cs_gallery_sorting(id,random_id){
	var gallery = []; // more efficient than new Array()
	jQuery('#gallery_sortable_'+random_id+' li').each(function(){
		var data_value	= jQuery.trim( jQuery(this).data('attachment_id'));
		 gallery.push(jQuery(this).data('attachment_id'));
	});
	
	jQuery("#"+id).val(gallery.toString());
}

/**
 * @Attachments
 *
 */
jQuery( function($){
	// Product gallery file uploads
	var directory_gallery_frame;
	var $cs_attachments_ids 	= $('#cs_vehicle_file_attach');
	var $directory_attachments  = $('#file_attachment_container ul.cs_attachments_list');

	jQuery('.add_file_attachmnets').on( 'click', 'input', function( event ) {
		var $el = $(this);
		
		var file_icon_url = jQuery("#file_icon_url").val();
		var attachment_ids = $cs_attachments_ids.val();

		event.preventDefault();

		// If the media frame already exists, reopen it.
		if ( directory_gallery_frame ) {
			directory_gallery_frame.open();
			return;
		}

		// Create the media frame.
		directory_gallery_frame = wp.media.frames.directory_gallery = wp.media({
			// Set the title of the modal.
			title: $el.data('choose'),
			button: {
				text: $el.data('update'),
			},
			states : [
				new wp.media.controller.Library({
					title: $el.data('choose'),
					filterable : 'all',
					multiple: true,
				})
			]
		});

		// When an image is selected, run a callback.
		directory_gallery_frame.on( 'select', function() {
			var selection = directory_gallery_frame.state().get('selection');
			selection.map( function( attachment ) {
				attachment = attachment.toJSON();

				if ( attachment.id ) {
					attachment_ids = attachment_ids ? attachment_ids + "," + attachment.id : attachment.id;

					$directory_attachments.append('\
						<li class="cs-file-list" data-attachment_id="' + attachment.id + '">\
							<img src="' + file_icon_url + '" />\
							<div class="actions">\
								<span><a href="#" class="delete" title="' + $el.data('delete') + '"><i class="icon-times"></i></a></span>\
							</div>\
						</li>');
					}
				});
				$cs_attachments_ids.val( attachment_ids );
			});

			// Finally, open the modal.
			directory_gallery_frame.open();
		});

		// Remove images
		$('#file_attachment_container').on( 'click', 'a.delete', function() {
			$(this).closest('li.cs-file-list').remove();
			return false;
		});
});


/*--------------------------------------------------------------
 * Plugin Option Saving
 *-------------------------------------------------------------*/
function plugin_option_save(admin_url){
	jQuery(".outerwrapp-layer,.loading_div").fadeIn(100);
	function newValues() {
	  var serializedValues = jQuery("#plugin-options input,#plugin-options select,#plugin-options textarea").serialize()+'&action=plugin_option_save';
	  return serializedValues;
	}
	var serializedReturn = newValues();
	 jQuery.ajax({
		type:"POST",
		url: admin_url,
		data:serializedReturn, 
		success:function(response){
			
			jQuery(".loading_div").hide();
			jQuery(".form-msg .innermsg").html(response);
			jQuery(".form-msg").show();
			jQuery(".outerwrapp-layer").delay(100).fadeOut(100)
			window.location.reload(true);
			slideout();
		}
	});
	//return false;
}
		

/*--------------------------------------------------------------
 * Plugin Reset Option
 *-------------------------------------------------------------*/
function cs_rest_plugin_options(admin_url){	
	"use strict";

	var var_confirm = confirm("You current Plugin options will be replaced with the default options.");
	if ( var_confirm == true ){
		var dataString = 'action=plugin_option_rest_all';
		jQuery.ajax({
			type:"POST",
			url: admin_url,
			data: dataString,
			success:function(response){
				
				jQuery(".form-msg").show();
				jQuery(".form-msg").html(response);
				jQuery(".loading_div").hide();
				
				window.location.reload(true);
				slideout();
			}
		});
	}
	//return false;
}

function cs_set_p_filename( file_value, admin_url, file_path ){
	"use strict";
	jQuery(".backup_action_btns").find( 'input[type="button"]' ).attr( 'data-file', file_value );
	jQuery(".backup_action_btns").find( '> a' ).attr( 'href', file_path+file_value );
	jQuery(".backup_action_btns").find( '> a' ).attr( 'download', file_value );
}
		
function cs_pl_backup_generate( admin_url ){
	"use strict";
	jQuery(".outerwrapp-layer,.loading_div").fadeIn(100);
	
	var dataString = 'action=cs_pl_opt_backup_generate';
	jQuery.ajax({
		type:"POST",
		url: admin_url,
		data:dataString, 
		success:function(response){
			
			jQuery(".loading_div").hide();
			jQuery(".form-msg .innermsg").html(response);
			jQuery(".form-msg").show();
			jQuery(".outerwrapp-layer").delay(100).fadeOut(100);
			window.location.reload(true);
			slideout();
		}
	});
	//return false;
}

jQuery('.backup_generates_area').on('click', '#cs-p-backup-delte', function(){
	
	var var_confirm = confirm("This action will delete your selected Backup File. Are you want to continue?");
	if ( var_confirm == true ){
		jQuery(".outerwrapp-layer,.loading_div").fadeIn(100);
		
		var admin_url = jQuery('.backup_generates_area').data('ajaxurl');
		var file_name = jQuery(this).data('file');
		
		var dataString = 'file_name='+file_name+'&action=cs_pl_backup_file_delete';
		jQuery.ajax({
			type:"POST",
			url: admin_url,
			data:dataString, 
			success:function(response){
				
				jQuery(".loading_div").hide();
				jQuery(".form-msg .innermsg").html(response);
				jQuery(".form-msg").show();
				jQuery(".outerwrapp-layer").delay(2000).fadeOut(100);
				window.location.reload(true);
				slideout();
			}
		});
		//return false;
	}
});

jQuery('.backup_generates_area').on('click', '#cs-p-backup-restore, #cs-p-backup-url-restore', function(){
	
	jQuery(".outerwrapp-layer,.loading_div").fadeIn(100);
	
	var admin_url = jQuery('.backup_generates_area').data('ajaxurl');
	var file_name = jQuery(this).data('file');
	
	var dataString = 'file_name='+file_name+'&action=cs_pl_backup_file_restore';
	
	if( typeof(file_name) === 'undefined' ) {
		
		var file_name = jQuery('#bkup_import_url').val();
		
		var dataString = 'file_name='+file_name+'&file_path=yes&action=cs_pl_backup_file_restore';
	}
	
	jQuery.ajax({
		type:"POST",
		url: admin_url,
		data:dataString, 
		success:function(response){
			
			jQuery(".loading_div").hide();
			jQuery(".form-msg .innermsg").html(response);
			jQuery(".form-msg").show();
			jQuery(".outerwrapp-layer").delay(2000).fadeOut(100);
			window.location.reload(true);
			slideout();
		}
	});
	//return false;
});

function price_option_save(admin_url,id){
	cs_remove_overlay('cs_'+id+'_popup','append');
	
	jQuery(".outerwrapp-layer,.loading_div").fadeIn(100);
	function newValues() {
	 	var serializedValues = jQuery("#cs_get_prices input,#cs_pricing_result input, #cs-booking-pricing input,#cs-booking-pricing select,#cs-booking-pricing textarea").serialize()+'&action=price_option_save';
	  return serializedValues;
	}
		
	var serializedReturn = newValues();
	 jQuery.ajax({
		type:"POST",
		url: admin_url,
		data:serializedReturn, 
		success:function(response){
			
			jQuery(".loading_div").hide();
			jQuery(".form-msg .innermsg").html(response);
			jQuery(".form-msg").show();
			jQuery(".outerwrapp-layer").delay(100).fadeOut(100)
			//window.location.reload(true);
			slideout();
		}
	});
	//return false;
}


/*--------------------------------------------------------------
 * Plugin Reset Option
 *-------------------------------------------------------------*/
 function cs_get_currencies( code ){
	 
	if( code != '' ){
		var dataString = 'code=' + code +
		'&action=cs_get_currency_symbol';
		var plugin_url	= jQuery("#cs_plugin_url").val();
		jQuery("#currency_sign").parent('.to-field').append("<span><i style='color:#fe9909;' class='icon-spinner8 icon-spin'></i></span>");
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: dataString,
			success: function(response) {
				jQuery("#currency_sign").val(response);
				jQuery("#currency_sign").parent('.to-field').find('span').remove();
			}
		});
	}
	
	return false;
}

jQuery(document).ready(function() {	 
	jQuery("#cs_currency_type").change(function(e) {
		cs_get_currencies(this.value);
    });
});

/* ---------------------------------------------------------------------------
 * Accomodation Toggle Function
 * --------------------------------------------------------------------------- */
	jQuery(".plain-info").find('.cslist-info').hide();
	jQuery('.info-toggle').on('click', function(e){
		e.preventDefault();
		var datalink = jQuery(this).attr('id');
		var active = jQuery(this).hasClass('active');
		if(active){
			jQuery(this).removeClass('active');
			jQuery(this).parents(".plain-info").find('.cslist-info').toggle( "slow");
			jQuery(this).find('i').removeClass().addClass('icon-plus8');
		}else{
			jQuery(this).addClass('active');
			jQuery(this).parents(".plain-info").find('.cslist-info').toggle( "slow");
			jQuery(this).find('i').removeClass().addClass('icon-minus8');
		}
	});

jQuery(document).ready(function(){
	jQuery(document).on('click', '.cs-send-inquiry-form', function(event){
		event.preventDefault();
		_this	= jQuery(this);

		var _name	= _this.parents('.reviews-modal').find("#cs-name").val();
		var _email	= _this.parents('.reviews-modal').find("#cs-email").val();
		var _subject	= _this.parents('.reviews-modal').find("#cs-subject").val();
		var _description	= _this.parents('.reviews-modal').find("#cs-description").val();
		var post_id			= _this.parents('.reviews-modal').data("post");
		var ajaxurl			= jQuery('.cs-listing').data('admin_url');
		
		if( _name == '' || _email == '' || _subject == '' || _description == ''  ) {
			alert('Please Fill all the fields.');
			return false;
		} else if( !validateEmail(_email)) { 
				alert('Please enter a valid email address.');
				return false;
		} else{
			
			_this.parents('.modal-body').find('.cs-messages').html();
			
			_this.parent('li').append("<span><i style='color:#fe9909;' class='icon-spinner8 icon-spin'></i></span>");
			
			function newValues() {
				  var serializedValues = 'post_id='+post_id+'&cs_name='+_name+'&cs_email='+_email+'&cs_subject='+_subject+'&cs_description='+_description+'&action=cs_send_inquiry_form';
				  return serializedValues;
			}
			
			var serializedReturn = newValues();
			
			jQuery.ajax({
				type: "POST",
				url: ajaxurl,
				data: serializedReturn,
				dataType: "json",
				success: function(response) {
					_this.parents('.modal-body').find('.cs-messages').html(response.message);
					_this.parents('.reviews-modal').find("#cs-name").val('');
					_this.parents('.reviews-modal').find("#cs-email").val('');
					_this.parents('.reviews-modal').find("#cs-subject").val('');
					_this.parents('.reviews-modal').find("#cs-description").val('');
					_this.parent('li').find('i').remove();
					_this.parents('.reviews-modal').hide();
				}
			});
		}

			
	});
	
	jQuery(document).on('click', '.cs-send-invite-form', function(event){
		event.preventDefault();
		_this	= jQuery(this);
		
		var items	= jQuery(".emails-tags").tagsinput('items');
		var email_array	= items[0];
		var emails_list	= email_array.toString();
		console.log( emails_list );
		
		
		console.log( 'aamri' );	
				
		var _emails	= _this.parents('.reviews-modal').find("#cs-emails").val();
		var _description	= _this.parents('.reviews-modal').find("#cs-description").val();
		var post_id			= _this.parents('.reviews-modal').data("post");
		var ajaxurl			= jQuery('.cs-listing').data('admin_url');
		
		
		if( _emails == '' ||  _description == ''  ) {
			alert('Please Fill all the fields.');
			return false;
		} else {
			
			_this.parents('.modal-body').find('.cs-messages').html();
			function newValues() {
				  var serializedValues = 'post_id='+post_id+'&cs_emails='+_emails+'&cs_description='+_description+'&action=cs_invite_friends';
				  return serializedValues;
			}
			
			var serializedReturn = newValues();
			_this.parent('li').append("<span><i style='color:#fe9909;' class='icon-spinner8 icon-spin'></i></span>");
			
			jQuery.ajax({
				type: "POST",
				url: ajaxurl,
				data: serializedReturn,
				dataType: "json",
				success: function(response) {
					_this.parents('.modal-body').find('.cs-messages').html(response.message);
					_this.parents('.reviews-modal').find("#cs-emails").val('');
					_this.parents('.reviews-modal').find("#cs-description").val('');
					_this.parent('li').find('i').remove();
					_this.parents('.reviews-modal').hide();
				}
			});
		}

			
	});
});
/* ---------------------------------------------------------------------------
 * Vehicle Ajax Listing & Filteration
 * --------------------------------------------------------------------------- */
	jQuery('.cs-vehicles-filter').on('click', function(e){
		function newValues() {
		  var serializedValues = jQuery("#plugin-options input").serialize()+'&action=cs_vehicles_listing_ajax';
		  return serializedValues;
		}
		var serializedReturn = newValues();
		
		jQuery.ajax({
			type: "POST",
			url: ajaxurl,
			data: dataString,
			success: function(response) {
				jQuery("#currency_sign").val(response);
				jQuery("#currency_sign").parent('.to-field').find('span').remove();
			}
		});
	});

/* ---------------------------------------------------------------------------
 * Add/Remove Vehicle
 * --------------------------------------------------------------------------- */
jQuery(document).ready(function() {	
	jQuery("#cs_vehicle_num").change(function(){
		counter	= 0;
		var vehicles_prefix_dummy  = jQuery("#cs_vehicles_prefix").val();
		var vehicles_prefix 	   = jQuery("#cs_vehicles_prefix").val();
		
		if( vehicles_prefix == '' ) {
			vehicles_prefix	= vehicles_prefix_dummy;
		}
		
		var vehicles_data_total = jQuery("#vehicles-holder").data('total');
		var vehicles_data  = jQuery("#vehicles-holder").data('vehicles').split(",");
		var keys_data   = jQuery("#vehicles-holder").data('keys').split(",");
		var status_data = jQuery("#vehicles-holder").data('status').split(",");
		var reason_data = jQuery("#vehicles-holder").data('reason').split("|||");
		
		var count = jQuery("#vehicles-holder ul li").size();
		var requested = jQuery("#cs_vehicle_num").val();

		if (requested > count) {
			
			for(i=count; i<requested; i++) {
			 counter++;
			 var str		= uniqID(5);
			 var del_cap	= '';
			 var status		= '';
			 
			 if( vehicles_data_total > 0 && i < vehicles_data_total ) {
			 	
				if( vehicles_data[i] ) {
					var uniq_name	= vehicles_data[i];
					var uniq_status	= status_data[i];
					var uniq_key	= keys_data[i];
					var uniq_reason	= reason_data[i];
					var status	= 'readonly="readonly"';
					var del_cap	= '<a href="javascript:;" class="delete-capcaity-vehicle"><i class="icon-trash4"></i></a>';
				} else{
					var uniq_name	= vehicles_prefix+(i+1);
				}
			 } else{
			 	var uniq_name	= vehicles_prefix+(i+1);
				var uniq_status	= 'active';
				var uniq_key	= uniqID(5);
				var uniq_reason	= '';
			 }
			 
			 
			 var $ctrl = '<li><input type="text" '+status+' class="vehicles_meta" value="'+uniq_name+'" name="cs_vehicle_meta[]" id="vehicle_meta"/><input type="hidden" value="'+uniq_key+'" name="cs_vehicle_key[]" id="vehicle_meta"/><input type="hidden" value="'+uniq_status+'" name="cs_vehicle_status[]" /><input type="hidden" value="'+uniq_reason+'" name="cs_vehicle_reason[]" /><i class="icon-arrows-alt"></i>'+del_cap+'<span class="name-checking"></span></li>'       
				jQuery("#vehicles-holder ul").append($ctrl);
				cs_check_availabilty();
			}
		} else if ( jQuery.trim(requested) == '' ){
			jQuery("#vehicles-holder ul").html('');
		} else if (requested < count) {
			var x = requested - 1;
			jQuery("#vehicles-holder ul li:gt(" + x + ")").remove();
		}
	});
	
	jQuery( "#cs_vehicles_data" ).sortable();
	
	
	
	function uniqID(length) {

			var charstoformid = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');
            if (! length) {
                length = Math.floor(Math.random() * charstoformid.length);
            }
            
			var uniqid = '';
            for (var i = 0; i < length; i++) {
                uniqid += charstoformid[Math.floor(Math.random() * charstoformid.length)];
            }
			
			// one last step is to check if this ID is already taken by an element before 
            if(jQuery("#"+uniqid).length == 0)
                return uniqid;
            else
                return uniqID(5)
      }
});

/**
 * Check Availabilty
 */ 

function cs_check_availabilty() {
	
	jQuery('input#vehicle_meta').keyup( function(e) { 
	 //then give it a second to see if the user is finished
	var timer;
	var name = jQuery(this).val();
	var serializedValues = jQuery("form").serialize();
	$this	= jQuery( this );
	var dataString = 'name=' + name + 
					 '&form_field_names=' + serializedValues + 
					 '&action=cs_check_name_availabilty'
	
		clearInterval(timer);  //clear any interval on key up
		timer = setTimeout(function() { //then give it a second to see if the user is finished
			$this.parent('li').find('.name-checking').html('<i class="icon-spinner8 icon-spin"></i>');	
			jQuery.ajax({
				type:"POST",
				url: ajaxurl,
				data: dataString,
				dataType: 'json',
				success:function(response){		
					if ( response.type == 'success' ) {
						$this.parent('li').find('.name-checking').html(response.message);
						jQuery('input[type="submit"]').removeAttr('disabled');
						/*jQuery("#cs_vehicles_data li").each(function(){
							var $this	= jQuery(this);
							if( $this.find('i.icon-times') ){
								jQuery('input[type="submit"]').attr('disabled','disabled');
							}
						});*/
						
					} else if ( response.type == 'error' ) {
						$this.parent('li').find('.name-checking').html(response.message);
						jQuery('input[type="submit"]').attr('disabled','disabled');
					} 
				}
			});
		},3000);		
	});
}

/* ---------------------------------------------------------------------------
	* Add reviews
 	* --------------------------------------------------------------------------- */
	function cs_reviews_submission(admin_url){
		'use strict';
		
		var email	= jQuery("#reviewer_email").val();
		var subject	= jQuery("#reviews_title").val();
		var name	= jQuery("#reviewer_name").val();
		var description	= jQuery("#reviews_description").val();
		
		if( email =='' || subject =='' || name =='' || description =='' ){
			alert('Please fill all fields.');
			return false;
		}
		
		if( !validateEmail(email)) { 
			alert('Please enter a valid email address.');
			return false;
		}
		
		jQuery(".review-message-type").html('');
		jQuery("#loading").html('<i class="icon-spinner8 icon-spin"></i>');
		jQuery.ajax({
			type:"POST",
			url: admin_url,
			dataType: "json",
			data:jQuery('#cs-reviews-form').serialize()+'&action=cs_add_reviews', 
			success:function(response){
				jQuery("#loading").html('');
				jQuery(".review-message-type").html(response.message);
				jQuery(".review-message-type").show();
			}
		});
		
		return false;
	}
	
	function validateEmail($email) {
	  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	  return emailReg.test( $email );
	}
/* ---------------------------------------------------------------------------
	* Get Vehicle
 	* --------------------------------------------------------------------------- */
	jQuery(document).ready(function() {	
		jQuery("#cs_get_vehicles").change(function(){
			'use strict';
			
			var vehicle_id	= jQuery(this).val();
			
			if( vehicle_id == '' ) {
				jQuery("#cs_block_data tbody").html('<tr class="odd"><td valign="top" colspan="4" class="dataTables_empty">No data available in table</td></tr>');
				return false;
			}
			
			jQuery(".review-message-type").html('');
			jQuery('#cs-loader').html('<i class="icon-spinner8 icon-spin"></i>');
			jQuery.ajax({
				type:"POST",
				url: ajaxurl,
				dataType: "json",
				data:'vehicle_id='+vehicle_id+'&action=cs_get_vehicles', 
				success:function(response){
					jQuery(".vehicles-data-wrapper").html(response.data);
					jQuery('#cs-loader').html('');
				}
			});
			
			return false;
		});
	});
	
function cs_update_vehicles(){
	jQuery('.cs-block-action').on('click', 'a', function(e){
		var $this			= jQuery(this);
		var data_key		= jQuery(this).data('key');
		var data_reference	= jQuery(this).data('reference');
		var reason			= $this.parents('.vehicles-data').find('input').val();
		var data_status		= $this.data('status');

		$this.parents('.cs-block-action').find('.cs-spinner').html('<i class="icon-spinner8 icon-spin"></i>');
		jQuery.ajax({
			type:"POST",
			url: ajaxurl,
			dataType: "json",
			data:'data_key='+data_key+'&vehicle_id='+data_reference+'&reason='+reason+'&status='+data_status+'&action=cs_update_vehicles', 
			success:function(response){
				$this.next('.cs-spinner').html('');
				if ( response.type == 'success' ) {
					jQuery('.cs-update-message p').html(response.message);
					jQuery('.cs-update-message').show();
					$this.removeClass('in-active');
					$this.addClass(response.status);
					$this.text(response.status);
					$this.parents('.cs-block-action').find('.cs-spinner').html('');
				} else if ( response.type == 'error' ) {
					jQuery('.cs-update-message p').html(response.message);
					jQuery('.cs-update-message').show();
					$this.parents('.cs-block-action').find('.cs-spinner').html('');
				} 
				
			}
		});
		
		return false;
		
	});
	
	jQuery('.cs-block-reason').on('click', 'a.edit-reason', function(e){
		var $this	= jQuery(this);
		console.log($this);
		$this.parent('.cs-block-reason').find('p').hide();
		$this.parent('.cs-block-reason').find('input').show();
		$this.hide();
		$this.next('.edit-reason-update').show();
		
	});
	
	jQuery('.cs-block-reason').on('click', 'a.edit-reason-update', function(e){
		var $this	= jQuery(this);
		$this.parent('.cs-block-reason').find('input').hide();
		var reason	= $this.parent('.cs-block-reason').find('input').val();
		$this.parent('.cs-block-reason').find('p').html(reason).show();
		$this.hide();
		$this.prev('.edit-reason').show();
		
		var data_key		= $this.data('key');
		var data_reference	= $this.data('reference');
		var data_status		= $this.data('status');
		
		jQuery.ajax({
			type:"POST",
			url: ajaxurl,
			dataType: "json",
			data:'data_key='+data_key+'&vehicle_id='+data_reference+'&reason='+reason+'&status='+data_status+'&action=cs_update_vehicles', 
			success:function(response){
				
			}
		});
		
		return false;
		
	});
}

/* ---------------------------------------------------------------------------
	* Get Vehicle For Booking
 	* --------------------------------------------------------------------------- */
	jQuery(document).ready(function() {	
		jQuery("#tab-booking-settings").on('click','#cs_search_vehicle', function(){
			'use strict';
			var $this	=  jQuery(this);
			
			var cs_type_id			= jQuery("#cs_type_id").val();
			var date_from			= jQuery("#cs_check_in_date").val();
			var date_to				= jQuery("#cs_check_out_date").val();
			var pickup_time			= jQuery("#cs_pickup_time").val();
			var dropup_time			= jQuery("#cs_dropup_time").val();
			var pickup_location		= jQuery("#cs_pickup_location").val();
			var dropup_location		= jQuery("#cs_dropup_location").val();
			var total_days			= jQuery("#cs_booking_num_days").val();
			var cs_station			= jQuery("#cs_station").val();
			
			if( cs_station == '' ) {
				cs_station	= 'off';
			}
			
			// Empty Old Data
			jQuery("#cs_bkng_gross_total").val('');
			jQuery('#cs_bkng_tax').val('');
			jQuery('#cs_bkng_grand_total').val('');
			jQuery('#cs_bkng_remaining').val('');
			jQuery('#cs_bkng_advance').val('');
			jQuery('#wrapper_vehicle_extras').html('');

			//console.log(values);

			if( date_from == '' ) {
				alert('Check in date is required');
				return false;
			} else if( date_to == '' ) {
				alert('Check in date is required');
				return false;
			} else if( pickup_time == '' ) {
				alert('Pickup time is required');
				return false;
			} else if( dropup_time == '' ) {
				alert('Dropup time is required');
				return false;
			} else if( pickup_location == '' ) {
				alert('Pickup location required.');
				return false;
			}
			
			if( cs_station == 'off' && dropup_location == '' ){
				alert('Please select Dropup Location');
				return false;
			}
			
			
			jQuery(".review-message-type").html('');
			jQuery(".wrapper_vehicle_detail").html('');
			
			$this.parent('.input-sec').append('<i class="icon-spinner8 icon-spin"></i>');
			jQuery.ajax({
				type:"POST",
				url: ajaxurl,
				dataType: "json",
				data:'date_from='+date_from+'&date_to='+date_to+'&pickup_time='+pickup_time+'&dropup_time='+dropup_time+'&pickup_location='+pickup_location+'&dropup_location='+dropup_location+'&cs_type_id='+cs_type_id+'&cs_station='+cs_station+'&total_days='+total_days+'&action=cs_get_available_vehicles', 
				success:function(response){
					if( response.type == 'success' ) {
						jQuery("#wrapper_vehicle_availability").html(response.output);
						jQuery("#wrapper_vehicle_detail").html(response.output_vehicles);
						jQuery("#wrapper_vehicle_extras").html('');
						jQuery("#wrapper_vehicle_availability").show();
						$this.parent('.input-sec').find('i').remove();
					} else{
						jQuery("#wrapper_vehicle_availability").html(response.message);
					}
					
				}
			});
			
			return false;
		});
	});

/* ---------------------------------------------------------------------------
* Check Vehicle Availabilty
* --------------------------------------------------------------------------- */
function cs_select_vehicle(){	
	jQuery(".bk-vehicle-availabilty").on('click','.cs-select-vehicle', function(){
		
		
		var _this		= jQuery(this);
		var post_id		= _this.data('post');
		var vehicle_id		= _this.data('vehicle');
		var vehicle_type		= _this.data('type');
		var total_days			= jQuery("#cs_booking_num_days").val();
		var cs_booking_id		= jQuery("#cs_booking_id").val();

		var date_from			= jQuery("#cs_check_in_date").val();
		var date_to				= jQuery("#cs_check_out_date").val();
		var start_time			= jQuery("#cs_pickup_time").val();
		var end_time			= jQuery("#cs_dropup_time").val();
		var cs_station			= jQuery("#cs_station").val();

		
			_this.parents('.bk-vehicle-availabilty').find('figure').append('<i class="icon-spinner8 icon-spin"></i>');
			jQuery.ajax({
				type:"POST",
				url: ajaxurl,
				dataType: "json",
				data:'date_from='+date_from+'&date_to='+date_to+'&start_time='+start_time+'&end_time='+end_time+'&vehicle_id='+vehicle_id+'&cs_booking_id='+cs_booking_id+'&total_days='+total_days+'&vehicle_type='+vehicle_type+'&post_id='+post_id+'&action=cs_get_vehicle_detail', 
				success:function(response){
						jQuery('.bk-vehicle-deail').html(response.selected_vehicle);
						jQuery('.wrapper_vehicle_detail').show();
						
						if( response.status == 'completed' ) {
							jQuery("#wrapper_vehicle_availability").html('');
							jQuery("#wrapper_vehicle_availability").hide();
							jQuery("#wrapper_vehicle_extras").html(response.selection_done);
						}
					
						//jQuery("#wrapper_vehicle_extras").html(response.extras);
						jQuery("#cs_bkng_gross_total").val(response.total_price);
						jQuery('#cs_bkng_tax').val(response.vat_price);
						jQuery('#cs_bkng_grand_total').val(response.grand_total);
						jQuery('#cs_bkng_remaining').val(response.remaining);
						jQuery('#cs_bkng_advance').val(response.advance);
				}
			});
		
		
		return false;
			
	});
}

/* ---------------------------------------------------------------------------
* Check Vehicle Extras
* --------------------------------------------------------------------------- */
function cs_vehicle_extras(){	

	// Extras Show Price ON Guests
	jQuery(".wrapper_vehicle_extras").on('change','#cs-total-guests', function(){
		
		var $this				= jQuery(this);
		var extra_id			= $this.data('extra_id');
		var guests				= $this.val();
		var days_input		= $this.parents('.total-area').find('.cs-total-days').length;
		var cs_extras_price		= $this.parents('li.extras-list').data('price');
		var cs_currency			= jQuery('#cs_currency_type').val();
		
		if( days_input ){
           var days	= $this.parents('.total-area').find('.cs-total-days').val();
        } else{
            var days	= '';
        }
		
		var total_price	= cs_extras_price * guests;
		if( days > 0 ) {
			total_price	= total_price * days;
		}
		
		$this.parents('.total-area').find('span.price').html(cs_currency + total_price.toFixed(2));
		$this.parents('.total-area').find('.cs_extras_price').val(total_price.toFixed(2));
		
		// Gross Calculation
		cs_gross_calculations();
		return false;
			
	});
	
	// Extras Show Price ON Nights
	jQuery(".wrapper_vehicle_extras").on('change','#cs-total-days', function(){
		
		var $this				= jQuery(this);
		var extra_id			= $this.data('extra_id');
		var days				= $this.val();
		var guests_input		= $this.parents('.total-area').find('.cs-total-guests').length;
		var cs_extras_price		= $this.parents('li.extras-list').data('price');
		var cs_currency			= jQuery('#cs_currency_type').val();
		
		/*if( guests_input ){
           var guests	= $this.parents('.total-area').find('.cs-total-guests').val();
        } else{
            var guests	= '';
        }*/
		
		//var total_price	= cs_extras_price * guests;
		
		var total_price	= cs_extras_price;
		
		if( days > 0 ) {
			total_price	= total_price * days;
		}
		
		$this.parents('.total-area').find('span.price').html(cs_currency + total_price.toFixed(2));
		$this.parents('.total-area').find('.cs_extras_price').val(total_price.toFixed(2));
		
		// Gross Calculation
		cs_gross_calculations();
		return false;
			
	});

/* ---------------------------------------------------------------------------
* Gross Calculations On Extras
* --------------------------------------------------------------------------- */
	jQuery('.wrapper_vehicle_extras').on('change', 'input[type="checkbox"]', function(e) {
		var total_price	= 0;
		var gross_price	= jQuery('.final_price').data('gross');
		
		jQuery(this).parents('.extras-list').find('select').prop('disabled', 'disabled');
		
		jQuery(".cs-extras-check:checked").each(function() {
			var $this	= jQuery(this);
			$this.parents('.extras-list').find('select').prop('disabled', false);
			var price	= $this.parents('.extras-list').find('.cs_extras_price').val();
			if( price && price !='undefined' ) {
				total_price = parseFloat(price) + parseFloat(total_price);	
			}
		});
		
		console.log(gross_price);
		console.log(total_price);
		total_price = parseFloat(gross_price) + parseFloat(total_price);
		console.log(total_price);
		//VAT Calculation
		var vat	= jQuery('.reservation-inner').data('vat');
		
		var vat_switch	= jQuery('.reservation-inner').data('vat_switch');
		
		if( vat_switch == 'on' ) {
			var vat_price	= ( total_price / 100 ) * vat;
		} else{
			var vat_price	= 0;
		}
		
		var grand_total	= parseFloat( vat_price ) + parseFloat( total_price );
		var advance		= jQuery('#cs_bkng_advance').val();
		
		jQuery('#cs_bkng_gross_total').val(total_price.toFixed(2));
		jQuery('#cs_bkng_tax').val(vat_price.toFixed(2));
		jQuery('#cs_bkng_grand_total').val(grand_total.toFixed(2));
		jQuery('#cs_bkng_remaining').val((grand_total - advance).toFixed(2));
	
	});
}

/* ---------------------------------------------------------------------------
* Admin Gross Calculations
* --------------------------------------------------------------------------- */
function cs_gross_calculations(){
	var total_price	= 0;
	var gross_price	= jQuery('.final_price').data('gross');
	
	
	jQuery(".cs-extras-check:checked").each(function() {
		var $this	= jQuery(this);
		var price	= $this.parents('.extras-list').find('.cs_extras_price').val();
		if( price && price !='undefined' ) {
			total_price = parseFloat(price) + parseFloat(total_price);	
		}
	});
	
	total_price = parseFloat(gross_price) + parseFloat(total_price);

	//VAT Calculation
	var vat	= jQuery('.reservation-inner').data('vat');
	var vat_switch	= jQuery('.reservation-inner').data('vat_switch');
	if( vat_switch == 'on' ) {
		var vat_price	= ( total_price / 100 ) * vat;
	} else{
		var vat_price	= 0;
	}
	
	var grand_total	= parseFloat( vat_price ) + parseFloat( total_price );
	var advance		= jQuery('#cs_bkng_advance').val();

		
	jQuery('#cs_bkng_tax').val(vat_price.toFixed(2));	
	jQuery('#cs_bkng_grand_total').val(grand_total.toFixed(2));
	jQuery('#cs_bkng_remaining').val((grand_total - advance).toFixed(2));
	jQuery('#cs_bkng_gross_total').val(total_price.toFixed(2));
}

/* ---------------------------------------------------------------------------
* Add Transaction
* --------------------------------------------------------------------------- */
jQuery(document).ready(function() {	
	jQuery('#cs_add_transaction').on('click', function(e) {
		var $this	= jQuery(this);
		var cs_trans_id				= jQuery("#cs_trans_id").val();
		var cs_booking_id			= jQuery("#cs_booking_id").val();
		var cs_trans_email			= jQuery("#cs_trans_email").val();
		var cs_trans_first_name		= jQuery('#cs_trans_first_name').val();
		var cs_trans_last_name		= jQuery("#cs_trans_last_name").val();
		var cs_trans_address		= jQuery("#cs_trans_address").val();
		var cs_trans_amount			= jQuery("#cs_trans_amount").val();
		var cs_trans_gateway		= jQuery("#cs_trans_gateway").val();
		var cs_trans_status			= jQuery("#cs_trans_status").val();
		
		if( cs_trans_id == '' || cs_booking_id == '' || cs_trans_email == '' || cs_trans_first_name == '' || cs_trans_last_name == '' ||  cs_trans_address == ''  ||  cs_trans_last_name == ''  ||  cs_trans_amount == '' ||  cs_trans_gateway == '' ||  cs_trans_status == ''  ) {
			alert('All the fields is required');
			return false;
		}
		
		jQuery('.message-wrap').hide();
		$this.parent('.input-sec').append('<i class="icon-spinner8 icon-spin"></i>');
		jQuery.ajax({
			type:"POST",
			url: ajaxurl,
			dataType: "json",
			data:'cs_trans_id='+cs_trans_id+
				 '&cs_booking_id='+cs_booking_id+
				 '&cs_trans_email='+cs_trans_email+
				 '&cs_trans_first_name='+cs_trans_first_name+
				 '&cs_trans_last_name='+cs_trans_last_name+
				 '&cs_trans_address='+cs_trans_address+
				 '&cs_trans_amount='+cs_trans_amount+
				 '&cs_trans_gateway='+cs_trans_gateway+
				 '&cs_trans_status='+cs_trans_status+
				 '&action=cs_add_transaction', 
			success:function(response){
				if( response.type == 'success' ) {
					jQuery('#cs_transactions_data tbody').append(response.data);
					$this.parent('.input-sec').find('i').remove();
					jQuery("#cs_trans_id").val('');
					jQuery("#cs_booking_id").val('');
					jQuery("#cs_trans_email").val('');
					jQuery('#cs_trans_first_name').val('');
					jQuery("#cs_trans_last_name").val('');
					jQuery("#cs_trans_address").val('');
					jQuery("#cs_trans_amount").val('');
					jQuery("#cs_trans_gateway").val('');
					jQuery("#cs_trans_status").val('');
					jQuery(".message-wrap").hide();
					jQuery('.cs-message').html(response.message);
					jQuery('.cs-message').removeClass('error').addClass('updated');
					jQuery('.message-wrap').show();
					jQuery('#cs_transactions_data').find('.dataTables_empty').parent('tr').remove();
					cs_remove_overlay('cs_transactions_pop','append');
		
				} else{
					jQuery('.cs-message').removeClass('updated').addClass('error');
					jQuery('.cs-message').html(response.message);
					jQuery('.message-wrap').show();
					$this.parent('.input-sec').find('i').remove();
				}
			}
		});
		
		return false;
			
	});
});
/* ---------------------------------------------------------------------------
* Add Customer
* --------------------------------------------------------------------------- */
jQuery(document).ready(function() {	
	jQuery('#cs_add_customer').on('click', function(e) {
		var $this	= jQuery(this);
		var cs_customer_first_name	= jQuery("#cs_add_customer_first_name").val();
		var cs_customer_last_name	= jQuery("#cs_add_customer_last_name").val();
		var cs_customer_email		= jQuery('#cs_add_customer_email').val();
		var cs_customer_address		= jQuery("#cs_add_customer_address").val();
		var cs_customer_name		= jQuery("#cs_add_cstmr_name option:selected").text();
		var cs_customer_phone		= jQuery("#cs_add_customer_phone").val();
		var cs_customer_city		= jQuery("#cs_add_customer_city").val();
		var cs_customer_country		= jQuery("#cs_add_customer_country").val();
		
		if( cs_customer_first_name == '' || cs_customer_last_name == '' || cs_customer_email == '' || cs_customer_address == ''  ||  cs_customer_phone == ''  ||  cs_customer_city == '' ||  cs_customer_country == ''  ) {
			alert('All the fields is required');
			return false;
		}else  if( !validateEmail(cs_customer_email)) { 
			alert('Please enter a valid email address');
			return false;
		}
		
		jQuery('.message-wrap').hide();
		$this.parent('.input-sec').append('<i class="icon-spinner8 icon-spin"></i>');
		jQuery.ajax({
			type:"POST",
			url: ajaxurl,
			dataType: "json",
			data:'&cs_customer_first_name='+cs_customer_first_name+
				 '&cs_customer_last_name='+cs_customer_last_name+
				 '&cs_customer_email='+cs_customer_email+
				 '&cs_customer_address='+cs_customer_address+
				 '&cs_customer_name='+cs_customer_name+
				 '&cs_customer_phone='+cs_customer_phone+
				 '&cs_customer_city='+cs_customer_city+
				 '&cs_customer_country='+cs_customer_country+
				 '&action=cs_add_customer', 
			success:function(response){
				if( response.type == 'success' ) {
					jQuery('#cs_custmr_data tbody').append(response.data);
					$this.parent('.input-sec').find('i').remove();
					jQuery("#cs_customer_first_name").val('');
					jQuery("#cs_customer_last_name").val('');
					jQuery('#cs_customer_email').val('');
					jQuery("#cs_customer_address").val('');
					jQuery("#cs_customer_name").val('');
					jQuery("#cs_customer_phone").val('');
					jQuery("#cs_customer_city").val('');
					jQuery("#cs_customer_country").val('');
					$this.parents('.cs-popup-content').find('.message-wrap').hide();
					jQuery('.cs-message').removeClass('error').addClass('updated');
					jQuery('.message-wrap').show();
					jQuery('#cs_transactions_data').find('.dataTables_empty').parent('tr').remove();
					cs_remove_overlay('cs_customer_pop','append');
					cs_remove_customer();
		
				} else{
					jQuery('.cs-message').removeClass('updated').addClass('error');
					jQuery('.cs-message').html(response.message);
					jQuery('.message-wrap').show();
					$this.parent('.input-sec').find('i').remove();
				}
			}
		});
		
		return false;
			
	});
});
/* ---------------------------------------------------------------------------
* Filters
* --------------------------------------------------------------------------- */
jQuery(document).ready(function() {	
	jQuery("#cs_transactions_data").on('change','.cs_filter_gateways', function(){
		var $this	= jQuery(this);
		var status	= jQuery(this).val();
		var transaction_id	= $this.data('key');
		$this.parent('td').append('<i class="icon-spinner8 icon-spin"></i>');
		$this.parent('td select').hide();
		jQuery.ajax({
			type:"POST",
			url: ajaxurl,
			dataType: "json",
			data:'status='+status+'&transaction_id='+transaction_id+'&action=cs_update_transaction_status', 
			success:function(response){
				$this.parent('td').find('i').remove();
				$this.parent('td select').show();
			}
		});
		
		return false;
	});
	
	// Delete Capacity Vehicle
	jQuery('#cs_vehicles_data').on('click', 'a.delete-capcaity-vehicle', function(e){
		var $this	= jQuery(this);
		var length	= jQuery('#cs_vehicles_data li').length - 1;

		if( length == '' ) {
			length	= 0;
		}
		
		$this.parent('li').remove();
		jQuery('#cs_vehicle_num').prop('selectedIndex',length);
	});
});

/* ---------------------------------------------------------------------------
* Add Hotel
* --------------------------------------------------------------------------- */
jQuery(document).ready(function() {	
	jQuery(".cs-popup-content").on('click','.type-action-btn', function(){
	
		var $this	= jQuery(this);
		var key		= $this.data('key');
		var image	= $this.data('image');
		var id		= $this.data('id');

		var $container				= jQuery(this).parents('.cs-popup-content');
		var cs_type_name			= $container.find("#cs_type_name").val();
		var cs_type_image			= $container.find("#cs_type_image"+image).val();
		
		if( cs_type_name == '') {
			alert('Name fields is required');
			return false;
		} else if( cs_type_image == '') {
			alert('Image fields is required');
			return false;
		}
		
		jQuery('.message-wrap').hide();
		$this.parents('#add_type_to_btn').append('<i class="icon-spinner8 icon-spin"></i>');
		jQuery.ajax({
			type:"POST",
			url: ajaxurl,
			dataType: "json",
			data:'&cs_type_name='+cs_type_name+
				 '&id='+id+
				 '&key='+key+
				 '&cs_type_image='+cs_type_image+
				 '&action=cs_add_types', 
			success:function(response){
				if( response.type == 'success' ) {
					jQuery('#cs_types_data tbody').append(response.data);
					$this.parent('#add_type_to_btn').find('i').remove();

					if( key == 'add' ) {
						$container.find("#cs_type_name").val('');
						$container.find(".message-wrap").hide();
						jQuery('#cs_types_data').find('.dataTables_empty').parent('tr').remove();
						cs_remove_overlay('cs_type_pop','append');
						jQuery('.cs-message').remove();
					}
					
					jQuery('.cs-message').html(response.message);
					jQuery('.cs-message').removeClass('error').addClass('updated');
					jQuery('.message-wrap').show();
					
					if( key == 'update' ) {
						window.location.reload(true);
					}
		
				} else{
					jQuery('.cs-message').removeClass('updated').addClass('error');
					jQuery('.cs-message').html(response.message);
					jQuery('.message-wrap').show();
					$this.parents('.input-sec').find('i').remove();
				}
			}
		});
		
		return false;
			
	});
});
function cs_delete_type(){
	jQuery('.type-action').on('click','.type-delete', function(e) {
		var $this	= jQuery(this);
		var key	= $this.parent('.type-action').data('key');
		
		jQuery('.message-wrap').hide();
		$this.parent('.type-action').append('<i class="icon-spinner8 icon-spin"></i>');
		jQuery.ajax({
			type:"POST",
			url: ajaxurl,
			dataType: "json",
			data:'&key='+key+
				 '&action=cs_remove_types', 
			success:function(response){
				if( response.type == 'success' ) {
					jQuery('.cs-update-message p').html(response.message);
					jQuery('.cs-update-message').show();
					$this.parents('.type-detail').remove();
					$this.parent('.type-action').find('i').remove();
				} else{
					$this.parent('.type-action').find('i').remove();
					jQuery('.cs-update-message p').html(response.message);
					jQuery('.cs-update-message').show();
				}
			}
		});
		
		return false;
			
	});
}
/*-------------------------------------------------------------------------------
 * 
 * Booking Functions Front End
 *
 -------------------------------------------------------------------------------*/
 

/* ---------------------------------------------------------------------------
* Search Widget
* --------------------------------------------------------------------------- */
jQuery(document).ready(function($) {						
	jQuery(".vehicle-search").on('click','.seach_vehicle_btn', function( event ){
		event.preventDefault();
		
		var _this	= jQuery(this);
		
		var _container		= _this.parents('.vehicle-search').find('.booking-members');
		var pickup_date		= _this.parents('.vehicle-search').find('input.pickup_date').val();
		var pickup_time		= _this.parents('.vehicle-search').find('input.pickup_time').val();
		
		var dropup_date		= _this.parents('.vehicle-search').find('input.dropup_date').val();
		var dropup_time		= _this.parents('.vehicle-search').find('input.dropup_time').val();
		
		var vehicle_type	= _this.parents('.vehicle-search').find('.vehicle-type').val();
		var pickup_dp		= _this.parents('.vehicle-search').find('.pickup_location').val();
		var dropup_dp		= _this.parents('.vehicle-search').find('.dropup_location').val();
		
		var station			= _this.parents('.vehicle-search').find('.station');
		var aged			= _this.parents('.vehicle-search').find('.aged');
			
		var flag	= 'true';

		if( pickup_date == '' || pickup_time == '' || dropup_date == '' || dropup_time == '' || vehicle_type == '' || pickup_dp == '' ){
			alert('Please fill all the fields');
			return false;
		}

		if( ( jQuery( station ).is(":checked") ) ){
			// Do Nothing
		} else if( dropup_dp =='' ){
			alert('Please select Dropup Location');
			return false;
		}
		
		if( jQuery( aged ).is(":checked") ){
			// Do Nothing
		} else{
			alert('Please select age.');
			return false;
		}
		
		_this.parents('.vehicle-search').find("#vehicle-seach").submit();            
		return true; // return false to cancel form action
		
	});
});

/* ---------------------------------------------------------------------------
* Edit Search
* --------------------------------------------------------------------------- */
jQuery(document).ready(function($) {						
	jQuery(".reservation-search").on('click','#cs-edit-search', function(){
		var $this	= jQuery(this);
		$this.parents('.reservation-search').hide();
		jQuery( '.reservation-form' ).show();
	});
	
	jQuery(".page-sidebar").on('click','#cs-edit-search', function(){
		var $this	= jQuery(this);
		$this.parents('.reservation-search').hide();
		jQuery( '.reservation-form' ).show();
	});
});

/* ---------------------------------------------------------------------------
* Post Data for reservation
* --------------------------------------------------------------------------- */
function cs_check_vehicle_availabilty(){
	jQuery(".cs-book-vehicle").on('click','.reserve-vehicle-btn', function(){
		var postFormStr	= '';
		var _this		= jQuery(this);
		var post_id		= _this.data('post');
		var vehicle_id		= _this.data('vehicle');
		var vehicle_type		= _this.data('type');
		var ajaxurl		= jQuery('.cs-ajax-listing').data('admin_url');
		cs_set_loader();
		
		jQuery.ajax({
			type:"POST",
			url: ajaxurl,
			dataType: "json",
			data:'vehicle_type='+vehicle_type+'&vehicle_id='+vehicle_id+'&post_id='+post_id+'&action=cs_check_availabilty', 
			success:function(response){
				console.log(response.grand_total);
				jQuery('.booking-tabs').show();
				jQuery('.cs-reserved-vehicle').html(response.selected_vehicle).show();	
				jQuery('.cs-ajax-listing').html(response.selection_done);
				jQuery('.amount-list').show();
				jQuery('.total-price').html(response.total_price);
				jQuery('.cs-vat-percent span').html(response.vat_price);
				jQuery('.grand-total em').html(response.grand_total);
				jQuery('.grand-total-wrap').show();
				jQuery('.cs-booking-grand-total').html(response.grand_total);
				jQuery('.cs-search-breadcrumbs').hide();
				jQuery('.cs-reservation-tabs').show();
				jQuery('.cs-process-outer').remove();
				cs_price_calculations();
				cs_process_booking();
				cs_placeholder_init();
			}
		});
			
		return false;
		
	});
	
}

/* ---------------------------------------------------------------------------
* Price Calculation
* --------------------------------------------------------------------------- */
function cs_price_calculations(){
	var total_price = 0;
	
	var cs_currency	= jQuery('.cs-gross-calculation').data('currency');
	jQuery(".cs-reserved-vehicle span").each(function() {
		var data_price	= jQuery(this).data('price');
		if( data_price && data_price !='undefined' ){
			total_price	+= parseFloat( data_price );
		}
	});

	total_price	= parseFloat( total_price );
	
	//VAT Calculation
	var vat	= jQuery('.cs-gross-calculation').data('vat');
	var vat_switch	= jQuery('.cs-gross-calculation').data('vat_switch');
	if( vat_switch == 'on' ) {
		var vat_price	= ( total_price / 100 ) * vat;
	} else{
		var vat_price	= 0;
	}

	var grand_total	= parseFloat( vat_price ) + parseFloat( total_price );
	
	var vat_html	= 'Vat('+vat+'%) <span>'+cs_currency+vat_price.toFixed(2)+'</span>';	
	jQuery('.grand-total em').html(cs_currency+grand_total.toFixed(2));
	jQuery('.cs-vat-percent').html(vat_html);
	jQuery('.cs-booking-grand-total').html(cs_currency+grand_total.toFixed(2));
}


/* ---------------------------------------------------------------------------
* Gross Calculations On Extras
* --------------------------------------------------------------------------- */
function cs_gross_calculation(){	
	jQuery('.booking-step').on('change', 'input[type="checkbox"]', function(e) {
			var delete_id	= jQuery(this).parents('.extras-list').find('.cs-extras-check').val();
			jQuery('extra-'+delete_id).remove();
			
			if( jQuery('.booking-extras li').length < 2 ) {
				jQuery('.booking-extras').hide();
			}
			
			var total_price = 0;
			var cs_currency			= jQuery('.cs-gross-calculation').data('currency');
			var gross_price			= jQuery('.cs-gross-calculation').data('price');
			var full_pay			= jQuery('.cs-gross-calculation').data('full_pay');
			var advance				= jQuery('.cs-gross-calculation').data('advance');
			
			jQuery(".cs-reserved-vehicle span").each(function() {
				var data_price	= jQuery(this).data('price');
				if( data_price && data_price !='undefined' ){
					total_price	+= parseFloat( data_price );
				}
			});
			
			jQuery(this).parents('.extras-list').find('select').prop('disabled', 'disabled');
			
			
			jQuery(".booking-extras").html('');
			jQuery(".cs-extras-check:checked").each(function() {
				var $this	= jQuery(this);
				$this.parents('.extras-list').find('select').prop('disabled', false);
				var price	= $this.parents('.extras-list').find('.cs_extras_price').val();
				if( price && price !='undefined' ) {
					total_price = parseFloat(price) + parseFloat(total_price);	
				}
				
				// Create Html
				var id		= $this.parents('.extras-list').find('.cs-extras-check').val();
				var label	= $this.parents('.extras-list').find('h5').html();
				var t_days	= $this.parents('.extras-list').find('#cs-total-days').val();
				
				var extras_data	= '';
				if( t_days && t_days !='' ) {
					extras_data	+= parseInt( t_days ) +' Days';
				}

				var extra_html	= '';
				var extra_price	= '';
				if( price && price !='undefined' ) {
					extra_price	= cs_currency+price;
				} else{
					extra_price	= 'Free';
				}
				
				extra_html	+= '<li class="extra-'+id+'"><i class="icon-check-circle"></i>'+label
								+ '<span>'+extra_price+'</span>'
								+ '</li>';
				
				jQuery(".booking-extras").append(extra_html);
				jQuery('.booking-extras').show();
			});
			
			total_price	= parseFloat( total_price );
			
			//VAT Calculation
			var vat	= jQuery('.cs-gross-calculation').data('vat');
			var vat_switch	= jQuery('.cs-gross-calculation').data('vat_switch');
			if( vat_switch == 'on' ) {
				var vat_price	= ( total_price / 100 ) * vat;
			} else{
				var vat_price	= 0;
			}
			
			var grand_total	= parseFloat( vat_price ) + parseFloat( total_price );
			
			var vat_html	= 'Vat('+vat+'%) <span>'+cs_currency+vat_price.toFixed(2)+'</span>';	
			jQuery('.grand-total em').html(cs_currency+grand_total.toFixed(2));
			jQuery('.cs-vat-percent').html(vat_html);
			jQuery('.amount-list .total-price').html(cs_currency+total_price.toFixed(2));
			jQuery('.cs-booking-grand-total').html(cs_currency+grand_total.toFixed(2));

		});
		
	// Gateway Calculation
	jQuery('#cs-gateway-wrap').on('click', 'input[type="radio"]', function(e) {
			
			var $this	= jQuery(this);
			var total_price			= 0.00;
			var due_total			= 0.00;
			var pay_now				= 0.00;
			var advance_total		= 0.00;
			
			var cs_currency			= jQuery('.cs-gross-calculation').data('currency');
			var gross_price			= jQuery('.cs-gross-calculation').data('price');
			var full_pay			= jQuery('.cs-gross-calculation').data('full_pay');
			var advance				= jQuery('.cs-gross-calculation').data('advance');
			
			jQuery(".booking-vehicles li div").each(function() {
				var data_price	= jQuery(this).data('price');
				if( data_price && data_price !='undefined' ){
					total_price	+= parseFloat( data_price );
				}
			});
			
			
			jQuery(".cs-extras-check:checked").each(function() {
				var $this	= jQuery(this);
				$this.parents('.extras-list').find('select').prop('disabled', false);
				var price	= $this.parents('.extras-list').find('.cs_extras_price').val();
				if( price && price !='undefined' ) {
					total_price = parseFloat(price) + parseFloat(total_price);	
				}
						
			});
			
			total_price	= parseFloat( total_price );
	
			//VAT Calculation
			var vat	= jQuery('.cs-gross-calculation').data('vat');
			var vat_switch	= jQuery('.cs-gross-calculation').data('vat_switch');
			if( vat_switch == 'on' ) {
				var vat_price	= ( total_price / 100 ) * vat;
			} else{
				var vat_price	= 0;
			}
			
			var grand_total	= parseFloat( vat_price ) + parseFloat( total_price );
			
			if( advance !='' ) {
				var advance_total	= ( grand_total / 100 ) * advance;
				due_total				= grand_total - advance_total;
				var pay_now				= advance_total;
			} else{
				grand_total		= grand_total;
			}  
			
			jQuery('.cs-deposit-amount span').html(cs_currency+advance_total.toFixed(2));
			jQuery('.cs-total-amount span').html(cs_currency+grand_total.toFixed(2));
			jQuery('.total-price-wrap span').html(cs_currency+total_price.toFixed(2));
			jQuery('.price-box h1').html(cs_currency+grand_total.toFixed(2));

		});
		
		// Set Payment Type
		jQuery('.radio-box').on('change', 'input[type="radio"]', function(e) {
			var $this	= jQuery(this);
			var cs_type	= $this.val();
			if( cs_type == 'full' ) {
				jQuery('.cs-deposit-amount').hide();
				jQuery('.cs-arrival-data').hide();
			} else{
				jQuery('.cs-deposit-amount').show();
				jQuery('.cs-arrival-data').show();
			}
		});
	
	// Extras Show Price ON Guest
	jQuery(".cs-check-list").on('change','#cs-total-guests', function(){
			
			var $this				= jQuery(this);
			var extra_id			= $this.data('extra_id');
			var guests				= $this.val();
			var days_input		= $this.parents('.extras-list').find('.cs-total-days').length;
			var cs_extras_price		= $this.parents('li.extras-list').data('price');
			var cs_currency			= jQuery('.cs-gross-calculation').data('currency');
			
			if( days_input ){
			   var days	= $this.parents('.extras-list').find('.cs-total-days').val();
			} else{
				var days	= '';
			}
			
			var total_price	= cs_extras_price * guests;
			if( days > 0 ) {
				total_price	= total_price * days;
			}
			
			$this.parents('.extras-list').find('small').html(cs_currency + total_price.toFixed(2));
			$this.parents('.extras-list').find('.cs_extras_price').val(total_price.toFixed(2));
			
			// Payment Calculation
			cs_payment_calculations();
			return false;
				
	});
	
	// Extras Show Price ON Nights
	jQuery(".assentioal-list").on('change','#cs-total-days', function(){
			
			var $this				= jQuery(this);
			var extra_id			= $this.data('extra_id');
			var days				= $this.val();
			//var guests_input		= $this.parents('.extras-list').find('.cs-total-guests').length;
			var cs_extras_price		= $this.parents('li.extras-list').data('price');
			var cs_currency			= jQuery('.cs-gross-calculation').data('currency');
			
			var total_price	= cs_extras_price;
			
			if( days > 0 ) {
				total_price	= total_price * days;
			}
			
			$this.parents('.extras-list').find('span').html(cs_currency + total_price.toFixed(2));
			$this.parents('.extras-list').find('.cs_extras_price').val(total_price.toFixed(2));
			
			// Payment Calculation
			cs_payment_calculations();
			return false;
				
	});
}
	
/* ---------------------------------------------------------------------------
* Gross Calculations
* --------------------------------------------------------------------------- */
function cs_payment_calculations(){
	var total_price = 0;
	var cs_currency			= jQuery('.cs-gross-calculation').data('currency');
	var gross_price			= jQuery('.cs-gross-calculation').data('price');
	var full_pay			= jQuery('.cs-gross-calculation').data('full_pay');
	var advance				= jQuery('.cs-gross-calculation').data('advance');
			
	jQuery(".cs-reserved-vehicle span").each(function() {
		var data_price	= jQuery(this).data('price');
		if( data_price && data_price !='undefined' ){
			total_price	+= parseFloat( data_price );
		}
	});
	
	jQuery(this).parents('.extras-list').find('select').prop('disabled', 'disabled');
	
	jQuery(".booking-extras").html('');
	jQuery(".cs-extras-check:checked").each(function() {
		var $this	= jQuery(this);
		$this.parents('.extras-list').find('select').prop('disabled', false);
		var price	= $this.parents('.extras-list').find('.cs_extras_price').val();
		if( price && price !='undefined' ) {
			total_price = parseFloat(price) + parseFloat(total_price);	
		}
		
		// Create Html
		var id		= $this.parents('.extras-list').find('.cs-extras-check').val();
		var label	= $this.parents('.extras-list').find('h5').html();

		var extra_html	= '';
		var extra_price	= '';
		if( price && price !='undefined' ) {
			extra_price	= cs_currency+price;
		} else{
			extra_price	= 'Free';
		}
		
		extra_html	+= '<li class="extra-'+id+'"><i class="icon-check-circle"></i>'+label
						+ '<span>'+extra_price+'</span>'
						+ '</li>';
		
		jQuery(".booking-extras").append(extra_html);
		jQuery('.booking-extras').show();
				
	});
	
	total_price	= parseFloat( total_price );

	//VAT Calculation
	var vat			= jQuery('.cs-gross-calculation').data('vat');
	var vat_switch	= jQuery('.cs-gross-calculation').data('vat_switch');
	if( vat_switch == 'on' ) {
		var vat_price	= ( total_price / 100 ) * vat;
	} else{
		var vat_price	= 0;
	}
	
	var grand_total	= parseFloat( vat_price ) + parseFloat( total_price );
	
	var vat_html	= 'Vat('+vat+'%) <span>'+cs_currency+vat_price.toFixed(2)+'</span>';	
	jQuery('.grand-total em').html(cs_currency+grand_total.toFixed(2));
	jQuery('.cs-vat-percent').html(vat_html);
	jQuery('.amount-list .total-price').html(cs_currency+total_price.toFixed(2));
	jQuery('.cs-booking-grand-total').html(cs_currency+grand_total.toFixed(2));
}

/* ---------------------------------------------------------------------------
* Confirm Booking
* --------------------------------------------------------------------------- */
function cs_make_payment(){

		var postFormStr	= '';
		var ajaxurl			= jQuery('.cs-ajax-listing').data('admin_url');
		var gateway			= jQuery('input[name=cs_payment_gateway]:checked').val();
		
		// Loader On Body
		cs_set_loader();
		
		var total_price	= 0.00;
		jQuery(".cs-reserved-vehicle span").each(function() {
			var data_price	= jQuery(this).data('price');
			if( data_price && data_price !='undefined' ){
				total_price	+= parseFloat( data_price );
			}
		});
		
		
		jQuery(".cs-extras-check:checked").each(function() {
			var $this	= jQuery(this);
			$this.parents('.extras-list').find('select').prop('disabled', false);
			var price	= $this.parents('.extras-list').find('.cs_extras_price').val();
			if( price && price !='undefined' ) {
				total_price = parseFloat(price) + parseFloat(total_price);	
			}
					
		});
		
		total_price	= parseFloat( total_price );
		
		//VAT Calculation
		var vat	= jQuery('.cs-gross-calculation').data('vat');
		var vat_switch	= jQuery('.cs-gross-calculation').data('vat_switch');
		if( vat_switch == 'on' ) {
			var vat_price	= ( total_price / 100 ) * vat;
		} else{
			var vat_price	= 0;
		}
		
		var grand_total	= parseFloat( vat_price ) + parseFloat( total_price );

		var serializedReturn = 'gateway='+gateway+'&gross_price='+total_price+'&vat_price='+vat_price+'&grand_total='+grand_total+'&'+jQuery('#booking_form').serialize()+'&action=cs_add_booking';
		
		jQuery.ajax({
			type:"POST",
			url: ajaxurl,
			dataType: "json",
			data: serializedReturn, 
			success:function(response){
				if( response.type == 'error' ) {
					jQuery('.cs-notification').html(response.message);
					jQuery('.cs-process-outer').remove();
				} else{
					if( response.gateway == 'transfer' ) {
						jQuery('.booking-widget').html( response.form );
						// Show Confirmation
						var active = jQuery('.cs-reservation-tabs').find('.booking-tabs .active a').data('id');
						jQuery('.booking-tabs > .active').next('li').addClass('active').prev('li').removeClass('active');
						jQuery('.booking-tabs > .active').next('li').find('a').trigger('click');
						var active = jQuery('.cs-reservation-tabs').find('.booking-tabs li.active a').data('id');
						jQuery('.cs-ajax-listing .tab-content').find('.tabs').hide();
						jQuery('.cs-ajax-listing .tab-content').find("#"+active).show();
								
						jQuery('.cs-process-outer').remove();
					} else{
						jQuery('body').append(response.form);
					}
				}
			}
		});
		
		return false;

}

/* ---------------------------------------------------------------------------
* Window Loader
* --------------------------------------------------------------------------- */
function cs_set_loader(){
	jQuery('.cs-ajax-listing').append('<div class="cs-process-outer"><div class="process-loader"><i class="icon-spinner8 icon-spin"></i></div></div>');
}

function cs_process_booking() {
	jQuery(".cs-process-wrap").on('click','a', function(){

		var active = jQuery('.cs-reservation-tabs').find('.booking-tabs .active a').data('id');
		
		if( typeof( active ) === 'undefined' ){
			//Do Nothing
		} else {
		
			var active = jQuery('.cs-reservation-tabs').find('.booking-tabs .active a').data('id');
			if( active == 'tab1' ) {
				cs_grand_calculation();
				
				var active = jQuery('.cs-reservation-tabs').find('.booking-tabs .active a').data('id');
				jQuery('.booking-tabs > .active').next('li').addClass('active').prev('li').removeClass('active');
				jQuery('.booking-tabs > .active').next('li').find('a').trigger('click');
				
				var active = jQuery('.cs-reservation-tabs').find('.booking-tabs .active a').data('id');
				jQuery('.cs-ajax-listing .tab-content').find('.tabs').hide();
				jQuery('.cs-ajax-listing .tab-content').find("#"+active).show();
			
			}else if( active == 'tab2' ) {
				var cs_f_name			= jQuery('#cs_f_name').val();
				var cs_l_name			= jQuery('#cs_l_name').val();
				var cs_email			= jQuery('#cs_email').val();
				
				if( cs_f_name =='' || cs_l_name == '' || cs_email == '' ) { 
					alert('Please fill all the required fields');
					return false;
				} else if( !validateEmail(cs_email)) { 
					alert('Please enter a valid email address');
					return false;
				}
				
				cs_make_payment();
			} 
			
			
			
		}
		
	 });
}

/* ---------------------------------------------------------------------------
* Gateway Fee Calculation
* --------------------------------------------------------------------------- */
function cs_grand_calculation(){
	var total_price = 0;
	var advance_total		= 0.00;
	var cs_currency			= jQuery('.cs-gross-calculation').data('currency');
	var gross_price			= jQuery('.cs-gross-calculation').data('price');
	var full_pay			= jQuery('.cs-gross-calculation').data('full_pay');
	var advance				= jQuery('.cs-gross-calculation').data('advance');
	var fee					= jQuery('.cs-gross-calculation').data('gateway_fee');
			
	jQuery(".cs-reserved-vehicle span").each(function() {
		var data_price	= jQuery(this).data('price');
		if( data_price && data_price !='undefined' ){
			total_price	+= parseFloat( data_price );
		}
	});
	
	
	jQuery(".cs-extras-check:checked").each(function() {
		var $this	= jQuery(this);
		$this.parents('.extras-list').find('select').prop('disabled', false);
		var price	= $this.parents('.extras-list').find('.cs_extras_price').val();
		if( price && price !='undefined' ) {
			total_price = parseFloat(price) + parseFloat(total_price);	
		}
				
	});
	
	total_price	= parseFloat( total_price );
	
	//VAT Calculation
	var vat	= jQuery('.cs-gross-calculation').data('vat');
	var vat_switch	= jQuery('.cs-gross-calculation').data('vat_switch');
	if( vat_switch == 'on' ) {
		var vat_price	= ( total_price / 100 ) * vat;
	} else{
		var vat_price	= 0;
	}
	
	var grand_total	= parseFloat( vat_price ) + parseFloat( total_price );
	
	if( advance !='' ) {
		var advance_total		= ( grand_total / 100 ) * advance;
		due_total				= grand_total - advance_total;
		var pay_now				= advance_total;
	} else{
		grand_total				= grand_total;
	}  
	
	jQuery('.grand-total em').html(cs_currency+grand_total.toFixed(2));
	jQuery('.amount-list .total-price').html(cs_currency+total_price.toFixed(2));
	jQuery('.cs-booking-grand-total').html(cs_currency+grand_total.toFixed(2));
	jQuery('.cs-deposit-amount').html(cs_currency+advance_total.toFixed(2));

}


/* ---------------------------------------------------------------------------
	* Search Vehicle Form
 	* --------------------------------------------------------------------------- */
	function cs_widget_form(){
		jQuery(".vehicle-search").on('click','#seach_vehicle_btn', function(){
			'use strict';
			var url			= jQuery('.cs-search-vehicle-elm').data('action');
			jQuery( '#vehicle-seach' ).submit();
		});
	}

/* ---------------------------------------------------------------------------
* Datepicker Calender
* --------------------------------------------------------------------------- */
function cs_widget_script(){
	 var startDate = new Date();
	 var FromEndDate = new Date();
	 var ToEndDate = new Date();
	 ToEndDate.setDate(ToEndDate.getDate()+365);
	 
	 jQuery('.pickup_date').datepicker({
		weekStart: 1,
		startDate: new Date(),
		format: 'dd.mm.yyyy',
		autoclose: true
	}).on('changeDate', function(selected){
		startDate = new Date(selected.date.valueOf());
		startDate.setDate(startDate.getDate(new Date(selected.date.valueOf())));
		jQuery('.dropup_date').datepicker('setStartDate', startDate);
	});
	
	jQuery('.dropup_date')
		.datepicker({
			weekStart: 1,
			startDate: new Date(),
			format: 'dd.mm.yyyy',
			autoclose: true
		}).on('changeDate', function(selected){
			FromEndDate = new Date(selected.date.valueOf());
			FromEndDate.setDate(FromEndDate.getDate(new Date(selected.date.valueOf())));
			jQuery('.pickup_date input').datepicker('setEndDate', FromEndDate);
	});
	
	//jQuery('.pickup_time').timepicker();
	//jQuery('.dropup_time').timepicker();
	
	//For 24 hours format
	jQuery('.pickup_time').timepicker({
      showMeridian: false
    });
	jQuery('.dropup_time').timepicker({
      showMeridian: false
    });
}

jQuery( '.vehicle-search' ).on('click','.station', function(){
	
	var _this = jQuery(this);
	if(_this.is(":checked")) {
		_this.parents('.vehicle-search').find('.dropup-wrap').slideUp('slow');
	} else{
		_this.parents('.vehicle-search').find('.dropup-wrap').slideDown('slow');
	}
});

jQuery( '#tab-booking-settings' ).on('click','.cs_station', function(){
	//alert('asd');
	var checkbox = jQuery(this);
	if(checkbox.is(":checked")) {
		jQuery('#wrapper_dropup_location').slideUp('slow');
	} else{
		jQuery('#wrapper_dropup_location').slideDown('slow');
	}
});

/**
 * Map
 */
function cs_map_location_load(){
	"use strict";
	jQuery.noConflict();
		(function(jQuery) {
		
		// for ie9 doesn't support debug console >>>
		if (!window.console) window.console = {};
		if (!window.console.log) window.console.log = function () { };
		// ^^^
		
		var GMapsLatLonPicker = (function() {
		
			var _self = this;
		
			///////////////////////////////////////////////////////////////////////////////////////////////
			// PARAMETERS (MODIFY THIS PART) //////////////////////////////////////////////////////////////
			_self.params = {
				defLat : 0,
				defLng : 0,
				defZoom : 1,
				queryLocationNameWhenLatLngChanges: true,
				queryElevationWhenLatLngChanges: true,
				mapOptions : {
					mapTypeId: google.maps.MapTypeId.ROADMAP,
					mapTypeControl: false,
					disableDoubleClickZoom: true,
					zoomControlOptions: true,
					streetViewControl: false
				},
				strings : {
					markerText : "Drag this Marker", 
					error_empty_field : "Couldn't find coordinates for this place",
					error_no_results : "Couldn't find coordinates for this place"
				}
			};
		
		
			///////////////////////////////////////////////////////////////////////////////////////////////
			// VARIABLES USED BY THE FUNCTION (DON'T MODIFY THIS PART) ////////////////////////////////////
			_self.vars = {
				ID : null,
				LATLNG : null,
				map : null,
				marker : null,
				geocoder : null
			};
		
			///////////////////////////////////////////////////////////////////////////////////////////////
			// PRIVATE FUNCTIONS FOR MANIPULATING DATA ////////////////////////////////////////////////////
			var setPosition = function(position) {
				_self.vars.marker.setPosition(position);
				_self.vars.map.panTo(position);
		
				jQuery(_self.vars.cssID + ".gllpZoom").val( _self.vars.map.getZoom() );
				jQuery(_self.vars.cssID + ".gllpLongitude").val( position.lng() );
				jQuery(_self.vars.cssID + ".gllpLatitude").val( position.lat() );
				
				jQuery(_self.vars.cssID).trigger("location_changed", jQuery(_self.vars.cssID));
				
				if (_self.params.queryLocationNameWhenLatLngChanges) {
					getLocationName(position);
				}
				if (_self.params.queryElevationWhenLatLngChanges) {
					getElevation(position);
				}
			};
			
			// for reverse geocoding
			var getLocationName = function(position) {
				var latlng = new google.maps.LatLng(position.lat(), position.lng());
				_self.vars.geocoder.geocode({'latLng': latlng}, function(results, status) {
					if (status == google.maps.GeocoderStatus.OK && results[1]) {
						jQuery(_self.vars.cssID + ".gllpLocationName").val(results[1].formatted_address);
					} else {
						jQuery(_self.vars.cssID + ".gllpLocationName").val("");
					}
					jQuery(_self.vars.cssID).trigger("location_name_changed", jQuery(_self.vars.cssID));
				});
			};
		
			// for getting the elevation value for a position
			var getElevation = function(position) {
				var latlng = new google.maps.LatLng(position.lat(), position.lng());
		
				var locations = [latlng];
		
				var positionalRequest = { 'locations': locations };
		
				_self.vars.elevator.getElevationForLocations(positionalRequest, function(results, status) {
					if (status == google.maps.ElevationStatus.OK) {
						if (results[0]) {
							jQuery(_self.vars.cssID + ".gllpElevation").val( results[0].elevation.toFixed(3));
						} else {
							jQuery(_self.vars.cssID + ".gllpElevation").val("");
						}
					} else {
						jQuery(_self.vars.cssID + ".gllpElevation").val("");
					}
					jQuery(_self.vars.cssID).trigger("elevation_changed", jQuery(_self.vars.cssID));
				});
			};
			
			// search function
			var performSearch = function(string, silent) {
				if (string == "") {
					if (!silent) {
						displayError( _self.params.strings.error_empty_field );
					}
					return;
				}
				_self.vars.geocoder.geocode(
					{"address": string},
					function(results, status) {
						if (status == google.maps.GeocoderStatus.OK) {
							jQuery(_self.vars.cssID + ".gllpZoom").val(11);
							_self.vars.map.setZoom( parseInt(jQuery(_self.vars.cssID + ".gllpZoom").val()) );
							setPosition( results[0].geometry.location );
						} else {
							if (!silent) {
								displayError( _self.params.strings.error_no_results );
							}
						}
					}
				);
			};
			
			// error function
			var displayError = function(message) {
				
			};
		
			///////////////////////////////////////////////////////////////////////////////////////////////
			// PUBLIC FUNCTIONS  //////////////////////////////////////////////////////////////////////////
			var publicfunc = {
		
				// INITIALIZE MAP ON DIV //////////////////////////////////////////////////////////////////
				init : function(object) {
		
					if ( !jQuery(object).attr("id") ) {
						if ( jQuery(object).attr("name") ) {
							jQuery(object).attr("id", jQuery(object).attr("name") );
						} else {
							jQuery(object).attr("id", "_MAP_" + Math.ceil(Math.random() * 10000) );
						}
					}
		
					_self.vars.ID = jQuery(object).attr("id");
					_self.vars.cssID = "#" + _self.vars.ID + " ";
		
					_self.params.defLat  = jQuery(_self.vars.cssID + ".gllpLatitude").val()  ? jQuery(_self.vars.cssID + ".gllpLatitude").val()		: _self.params.defLat;
					_self.params.defLng  = jQuery(_self.vars.cssID + ".gllpLongitude").val() ? jQuery(_self.vars.cssID + ".gllpLongitude").val()	    : _self.params.defLng;
					_self.params.defZoom = jQuery(_self.vars.cssID + ".gllpZoom").val()      ? parseInt(jQuery(_self.vars.cssID + ".gllpZoom").val()) : _self.params.defZoom;
					
					_self.vars.LATLNG = new google.maps.LatLng(_self.params.defLat, _self.params.defLng);
		
					_self.vars.MAPOPTIONS		 = _self.params.mapOptions;
					_self.vars.MAPOPTIONS.zoom   = _self.params.defZoom;
					_self.vars.MAPOPTIONS.center = _self.vars.LATLNG; 
		
					_self.vars.map = new google.maps.Map(jQuery(_self.vars.cssID + ".gllpMap").get(0), _self.vars.MAPOPTIONS);
					_self.vars.geocoder = new google.maps.Geocoder();
					_self.vars.elevator = new google.maps.ElevationService();
		
					_self.vars.marker = new google.maps.Marker({
						position: _self.vars.LATLNG,
						map: _self.vars.map,
						title: _self.params.strings.markerText,
						draggable: true
					});
		
					// Set position on doubleclick
					google.maps.event.addListener(_self.vars.map, 'dblclick', function(event) {
						setPosition(event.latLng);
					});
				
					// Set position on marker move
					google.maps.event.addListener(_self.vars.marker, 'dragend', function(event) {
						setPosition(_self.vars.marker.position);
					});
			
					// Set zoom feld's value when user changes zoom on the map
					google.maps.event.addListener(_self.vars.map, 'zoom_changed', function(event) {
						jQuery(_self.vars.cssID + ".gllpZoom").val( _self.vars.map.getZoom() );
						jQuery(_self.vars.cssID).trigger("location_changed", jQuery(_self.vars.cssID));
					});
		
					// Update location and zoom values based on input field's value 
					jQuery(_self.vars.cssID + ".gllpUpdateButton").bind("click", function() {
						var lat = jQuery(_self.vars.cssID + ".gllpLatitude").val();
						var lng = jQuery(_self.vars.cssID + ".gllpLongitude").val();
						var latlng = new google.maps.LatLng(lat, lng);
						_self.vars.map.setZoom( parseInt( jQuery(_self.vars.cssID + ".gllpZoom").val() ) );
						setPosition(latlng);
					});
		
					// Search function by search button
					jQuery(_self.vars.cssID + ".gllpSearchButton").bind("click", function() {
						performSearch( jQuery(_self.vars.cssID + ".gllpSearchField").val(), false );
					});
		
					// Search function by gllp_perform_search listener
					jQuery(document).bind("gllp_perform_search", function(event, object) {
						performSearch( jQuery(object).attr('string'), true );
					});
		
					// Zoom function triggered by gllp_perform_zoom listener
					jQuery(document).bind("gllp_update_fields", function(event) {
						var lat = jQuery(_self.vars.cssID + ".gllpLatitude").val();
						var lng = jQuery(_self.vars.cssID + ".gllpLongitude").val();
						var latlng = new google.maps.LatLng(lat, lng);
						_self.vars.map.setZoom( parseInt( jQuery(_self.vars.cssID + ".gllpZoom").val() ) );
						setPosition(latlng);
					});
				}
		
			}
			
			return publicfunc;
		});
		
		jQuery(document).ready( function() {
			jQuery(".gllpLatlonPicker").each(function() {
				(new GMapsLatLonPicker()).init( jQuery(this) );
			});
		});
		
		jQuery(document).bind("location_changed", function(event, object) {
			console.log("changed: " + jQuery(object).attr('id') );
		});
		
}(jQuery));	
	
}

// Search Map
function cs_search_map(location){
	"use strict";
 	jQuery('.gllpSearchField').val(location);
	setTimeout(function(){
		jQuery(".gllpSearchButton").trigger("click");
	},10);
}

function cs_gl_search_map() {
	"use strict";
    var vals;
    vals = jQuery('#loc_address').val();
    jQuery('.gllpSearchField').val(vals);
}

function cs_job_loc_sugg_change(value) {
	"use strict";
    var $ = jQuery;
    if (value == 'website') {
        $("#cs_search_by_location_select").show();
    }
    else {
        $("#cs_search_by_location_select").hide();
    }
}

/**
 * Value toggle
 */
function cs_search_by_location_change(value) {
	"use strict";
    var $ = jQuery;
    if (value == 'single_city') {
        $("#cs_search_by_location_city_select").show();
    }
    else {
        $("#cs_search_by_location_city_select").hide();
    }
}

/**
 * Place Holder Init
 */
function cs_placeholder_init(value) {
    jQuery('input,textarea').focus(function(){
       jQuery(this).data('placeholder',jQuery(this).attr('placeholder'));
       jQuery(this).attr('placeholder','');
    });
    jQuery('input,textarea').blur(function(){
       jQuery(this).attr('placeholder',jQuery(this).data('placeholder'));
    });
}